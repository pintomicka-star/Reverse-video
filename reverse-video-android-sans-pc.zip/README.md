# Reverse Video Android

Ce projet est préparé pour construire l'APK Android dans GitHub Actions, sans PC.

Important : les fichiers FFmpeg doivent être installés par `npm install`; le traitement de la vidéo reste local sur le téléphone. Aucun fichier vidéo n'est envoyé à un serveur.

Sur téléphone :
1. Créer un dépôt GitHub.
2. Importer tous les fichiers de ce ZIP.
3. Ouvrir Actions > Build Android APK > Run workflow.
4. Une fois terminé, télécharger l'artefact `reverse-video-debug-apk`.
5. Extraire l'APK et l'installer sur Android.

La version actuelle utilise encore un lien de téléchargement pour la sortie. Une prochaine version pourra utiliser l'API Android pour enregistrer directement dans la galerie.
